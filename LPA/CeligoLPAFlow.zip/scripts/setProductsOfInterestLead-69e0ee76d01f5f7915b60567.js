/**
 * postResponseMap
 *
 * Celigo Post-Response Map script for the HubSpot → Salesforce lead sync flow.
 *
 * PURPOSE:
 *   2. Merges the incoming `comments` field (prefixed with a timestamp) with
 *      the existing Salesforce lead comment (`sf_Existing_Comment`), each on
 *      its own line.
 *
 * PRODUCT FIELDS MERGED (in priority order):
 *   1. sf_Existing_Lead_Primary_Product_of_Interest  — Primary product on the existing SF lead
 *   2. sf_Existing_Lead_Secondary_Product_of_Interest — Secondary product on the existing SF lead
 *   3. sf_Existing_Lead_Products_of_Interest          — Full product list on the existing SF lead
 *   4. form_products_of_interest__c                   — Product list from the HubSpot contact
 *   5. form_primary_product_interest__c               — Primary product from the HubSpot contact
 *   6. form_secondary_product_interest                — Secondary product from the HubSpot contact
 *
 * DEDUPLICATION:
 *   Products are compared as exact strings (case-sensitive). The first
 *   occurrence of each product is kept; subsequent duplicates are dropped.
 *   Order is preserved based on the field priority above.
 *
 * COMMENT MERGING:
 *   - The incoming `comments` value is prefixed with a timestamp (M/D/YYYY HH:MM:SS).
 *   - If `sf_Existing_Comment` is present, it is appended on a new line after
 *     the timestamped incoming comment.
 *   - If `sf_Existing_Comment` is null/empty, only the timestamped comment is used.
 *
 * EXAMPLE (comments merge):
 *   comments            = "Testing Acquia Web Governance lead"
 *   sf_Existing_Comment = "Testing the notes"
 *
 *   Result → comments = "5/11/2026 18:11:16 Testing Acquia Web Governance lead
 *                        Testing the notes"
 *
 * OTHER TRANSFORMATIONS:
 *   - `sf_Existing_Lead_Id` is wrapped in single quotes for safe SOQL usage
 *     in downstream lookup queries (e.g. WHERE Id = '00QVD000...')
 *
 * OUTPUT:
 *   Returns the mutated `postResponseMapData` array. The key fields written are:
 *   - `form_products_of_interest__c` — semicolon-delimited merged product string
 *   - `comments`                     — timestamp-prefixed and merged comment string
 *
 * LAST UPDATED: May 2026
 */
function postResponseMap(options) {
  const data = options.postResponseMapData || [];

  /**
   * toTokens
   * Splits a semicolon-delimited string into an array of trimmed, non-empty tokens.
   * Returns an empty array for null, undefined, or empty values.
   *
   * @param {*} value - The value to tokenize (typically a string or null)
   * @returns {string[]} Array of trimmed product name strings
   */
  const toTokens = (value) => {
    if (!value) return [];
    return String(value)
      .split(";")
      .map(v => v.trim())
      .filter(Boolean);
  };

  /**
   * formatTimestamp
   * Returns the current date and time as a human-readable string in the
   * format M/D/YYYY HH:MM:SS (24-hour, UTC).
   *
   * @returns {string} Formatted timestamp string (e.g. "5/11/2026 18:11:16")
   */
  const formatTimestamp = () => {
    const now = new Date();
    const month = now.getUTCMonth() + 1;
    const day = now.getUTCDate();
    const year = now.getUTCFullYear();
    const hours = String(now.getUTCHours()).padStart(2, "0");
    const minutes = String(now.getUTCMinutes()).padStart(2, "0");
    const seconds = String(now.getUTCSeconds()).padStart(2, "0");
    return `${month}/${day}/${year} ${hours}:${minutes}:${seconds}`;
  };

  /**
   * mergeComments
   * Prefixes the incoming comment with a timestamp, then appends the existing
   * Salesforce comment on a new line if one is present.
   *
   * @param {string|null} incomingComment  - The new comment from the HubSpot form submission
   * @param {string|null} existingComment  - The existing comment on the Salesforce lead record
   * @returns {string} Merged comment string
   */
  const mergeComments = (incomingComment, existingComment) => {
    const parts = [];
    if (incomingComment && incomingComment.trim()) {
      parts.push(`${formatTimestamp()} ${incomingComment.trim()}`);
    }
    if (existingComment && existingComment.trim()) {
      parts.push(existingComment.trim());
    }
    return parts.join("\n");
  };

  data.forEach(row => {

    // Merge the incoming comment (with timestamp) and the existing SF lead comment
    row.comments = mergeComments(row.comments, row.sf_Existing_Comment);

    // Wrap the existing Salesforce Lead ID in single quotes for safe SOQL query usage
    if (row.sf_Existing_Lead_Id) {
      row.sf_Existing_Lead_Id = `'${row.sf_Existing_Lead_Id}'`;
    }
  });

  return data;
}