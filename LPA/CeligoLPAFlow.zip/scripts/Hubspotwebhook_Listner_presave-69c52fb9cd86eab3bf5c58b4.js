function preSavePage(options) {
  const PRODUCT_MAP = {
    "Website Design & Hosting": "CivicEngage",
    "NextRequest": "NextRequest",
    "Social Media Archiving": "ArchiveSocial",
    "ArchiveSocial": "ArchiveSocial",
    "Agenda & Meeting Management": "CivicClerk",
    "Recreation Management Software": "CivicRec",
    "311 Citizen Request Management": "SeeClickFix",
    "Citizen Request Management": "SeeClickFix",
    "Community Development": "CivicGov",
    "Permitting, Planning, Licensing Software": "CivicGov",
    "Digital Optimization": "CivicOptimize",
    "Web Accessibility": "Accessibility",
    "Monsido": "Accessibility",
    "Mass Notification System": "CivicReady",
    "Codification": "Code and Supp",
    "Asset Management": "Asset Management"
  };
  const KNOWN_PRODUCT_VALUES = {
    "CivicEngage": true,
    "NextRequest": true,
    "ArchiveSocial": true,
    "CivicClerk": true,
    "CivicRec": true,
    "SeeClickFix": true,
    "CivicGov": true,
    "CivicOptimize": true,
    "Accessibility": true,
    "CivicReady": true,
    "Code and Supp": true,
    "Asset Management": true
  };

  function asString(value) {
    if (value === null || value === undefined) return "";
    if (Array.isArray(value)) {
      return value.map(asString).filter(Boolean).join(";");
    }
    if (typeof value === "object") {
      if (value.value !== undefined) return asString(value.value);
      return "";
    }
    return String(value).trim();
  }

  function unique(values) {
    var seen = {};
    var out = [];
    values.forEach(function (value) {
      var v = asString(value);
      if (v && !seen[v]) {
        seen[v] = true;
        out.push(v);
      }
    });
    return out;
  }

  function splitSemicolonValues(value) {
    return asString(value)
      .split(";")
      .map(function (v) {
        return v.trim();
      })
      .filter(function (v) {
        return v.length > 0;
      });
  }

  // Reads properties[fieldName] and stringifies it. Works whether the value
  // is a raw scalar (new flat webhook payloads) or a HubSpot-style
  // { value: ... } wrapper (older batch-export payloads) -- asString()
  // unwraps .value automatically when present.
  function getPropertyValue(properties, fieldName) {
    if (!properties || properties[fieldName] === undefined || properties[fieldName] === null) return "";
    return asString(properties[fieldName]);
  }

  function getFirstMatch(properties, fieldNames) {
    for (var i = 0; i < fieldNames.length; i++) {
      var value = getPropertyValue(properties, fieldNames[i]);
      if (value) return value;
    }
    return "";
  }

  // Some incoming payloads carry a field under a clean, known key
  // (e.g. "campaign"), others carry the same logical field under a
  // dynamically generated form-field key (e.g.
  // "field_campaign_0_1_aa6075b2") where the trailing hash is
  // form/session-specific and not reliable to hardcode. This checks the
  // known exact names first, then falls back to a regex-prefix match
  // against every key on the record so newly-hashed variants of the same
  // field are still picked up.
  function getFieldValue(properties, exactNames, patterns) {
    var direct = getFirstMatch(properties, exactNames || []);
    if (direct) return direct;
    if (patterns && properties) {
      var keys = Object.keys(properties);
      for (var p = 0; p < patterns.length; p++) {
        for (var k = 0; k < keys.length; k++) {
          if (patterns[p].test(keys[k])) {
            var val = asString(properties[keys[k]]);
            if (val) return val;
          }
        }
      }
    }
    return "";
  }

  function translateProduct(value) {
    var raw = asString(value);
    if (!raw) return "";
    if (PRODUCT_MAP[raw]) return PRODUCT_MAP[raw];
    if (KNOWN_PRODUCT_VALUES[raw]) return raw;
    return "";
  }

  // Combines solutions, solutions_2, and products/products_of_interest
  // (whatever key each happens to arrive under) into one deduplicated,
  // translated, semicolon-joined product list.
  function normalizeProducts(properties) {
    var sources = [
      getPropertyValue(properties, "solutions"),
      getFieldValue(properties, ["solutions_2"], [/^field_solutions_2_/i]),
      getFieldValue(properties, ["products", "products_of_interest"], [/^field_products_of_interest_/i])
    ];
    var allValues = [];
    sources.forEach(function (sourceValue) {
      allValues = allValues.concat(splitSemicolonValues(sourceValue));
    });
    var translated = allValues
      .map(function (value) {
        return translateProduct(value);
      })
      .filter(Boolean);
    return unique(translated).join(";");
  }

  function getFormId(record) {
    if (
      record &&
      record["form-submissions"] &&
      record["form-submissions"].length > 0 &&
      record["form-submissions"][0]["form-id"]
    ) {
      return asString(record["form-submissions"][0]["form-id"]);
    }
    return "";
  }

  var latestHs2SfTime = (options.job && options.job.startedAt) ? options.job.startedAt : "";

  var normalizedData = (options.data || []).map(function (pageRecord) {
    var record = pageRecord.record || pageRecord;
    // Older payloads nest fields under record.properties; the new flat
    // webhook payload puts fields directly on the record itself.
    var properties = record.properties || record;

    var email = getPropertyValue(properties, "email");
    var firstname = getPropertyValue(properties, "firstname");
    var lastname = getPropertyValue(properties, "lastname");
    var recent_conversion_event_name = getPropertyValue(properties, "recent_conversion_event_name");
    var company = getPropertyValue(properties, "company");
    var phone = getPropertyValue(properties, "phone");
    var website = getPropertyValue(properties, "website");
    var statePicklist = getPropertyValue(properties, "state_picklist");
    var lifecycleStage = getPropertyValue(properties, "lifecyclestage");
    var mqlCode = getPropertyValue(properties, "most_recent_mql_code");
    var campaign = getFieldValue(properties, ["campaign"], [/^field_campaign_/i]);
    var leadSource = getFieldValue(properties, ["leadsource"], [/^field_leadsource_/i]);
    var hsLatestSourceData1 = getPropertyValue(properties, "hs_latest_source_data_1");
    var jobTitle = getFirstMatch(properties, ["Job title", "jobtitle", "job_title"]);
    var tradeShowNotes = getFirstMatch(properties, ["trade_show_notes", "tradeshow_notes__c"]);
    var organizationName = getPropertyValue(properties, "organization_name");
    var formId = getFormId(record);
    var hsLatestSource      = getPropertyValue(properties, "hs_latest_source")      || null;
    var hsAnalyticsSource   = getPropertyValue(properties, "hs_analytics_source")   || null;
    var recentConversionDate = getPropertyValue(properties, "recent_conversion_date") || null;
    var createDate          = getPropertyValue(properties, "createdate")             || null;

    if (!company) {
      company = organizationName;
    }

    return {
      form_email: email,
      form_firstname: firstname,
      form_lastname: lastname,
      form_recent_conversion_event_name: recent_conversion_event_name,
      form_company: company,
      form_phone: phone,
      form_website: website,
      form_state_picklist: statePicklist,
      form_lifecyclestage: lifecycleStage,
      form_most_recent_mql_code: mqlCode,
      form_campaign: campaign,
      form_leadsource: leadSource,
      form_jobtitle: jobTitle,
      form_products_of_interest__c: normalizeProducts(properties),
      form_primary_product_interest__c: getFieldValue(properties, ["primary_product_interest__c"], [/^field_primary_product_interest_+/i]),
      form_secondary_product_interest: getFieldValue(properties, ["secondary_product_interest"], [/^field_secondary_product_interest_+/i]),
      form_tradeshow_notes__c: mqlCode === "TSH" ? tradeShowNotes : "",
      form_hs_object_id: getPropertyValue(properties, "hs_object_id"),
      form_contact_id: getPropertyValue(properties, "hs_object_id"),
      form_form_id: formId,
      form_latest_hs2sf_time: latestHs2SfTime,
      form_hs_latest_source:       hsLatestSource,
      form_hs_analytics_source:    hsAnalyticsSource,
      form_recent_conversion_date: recentConversionDate,
      form_createdate:             createDate,
      form_hs_latest_source_data_1: hsLatestSourceData1
    };
  });

  return {
    data: normalizedData,
    errors: options.errors || [],
    abort: false,
    newErrorsAndRetryData: []
  };
}